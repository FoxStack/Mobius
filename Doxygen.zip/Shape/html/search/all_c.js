var searchData=
[
  ['setbrush_20',['setBrush',['../class_shape.html#a29e6a60d7bcbe0e919d8adca3380a099',1,'Shape']]],
  ['setcenter_21',['SetCenter',['../class_ellipse.html#ac142e3aaed570d7e7875323427bb0adf',1,'Ellipse']]],
  ['setcoord_22',['SetCoord',['../class_shape.html#a3b289dc17fd078ae4e293ac3ef508267',1,'Shape::SetCoord()'],['../class_text.html#a4c9557efda415231d5f8ba3945dbc649',1,'Text::SetCoord()']]],
  ['setdimensions_23',['SetDimensions',['../class_ellipse.html#a29ceccdf409e8a266c89eeac8248dc12',1,'Ellipse::SetDimensions()'],['../class_rectangle.html#a5fbab4019cf7cc71eb8f8b1b1f3593b9',1,'Rectangle::SetDimensions()']]],
  ['setfontfamily_24',['SetFontFamily',['../class_text.html#aa37852b276fdcca8d0ebcdfa2276c886',1,'Text']]],
  ['setfontsize_25',['SetFontSize',['../class_text.html#a8f773d76ae3e4806e8448e7800e2c002',1,'Text']]],
  ['setfontstyle_26',['SetFontStyle',['../class_text.html#ae18ee1094b7964be4abca2124af649b8',1,'Text']]],
  ['setfontweight_27',['SetFontWeight',['../class_text.html#a8090c53305fdcbdada5c99a097102d38',1,'Text']]],
  ['setpen_28',['setPen',['../class_shape.html#a3251fa122274b69056a2a272c5cf795e',1,'Shape']]],
  ['setpointone_29',['SetPointOne',['../class_line.html#a3f4df8df51f2712ba85549502a7bec99',1,'Line']]],
  ['setpointtwo_30',['SetPointTwo',['../class_line.html#ae01991d3b19f6f7584bee0dfa268fb5a',1,'Line']]],
  ['setstring_31',['SetString',['../class_text.html#ae93b51befbda5be92a0f4c4e5f96648a',1,'Text']]],
  ['settextalignment_32',['SetTextAlignment',['../class_text.html#a7fda7623b396d7484e70cb35239fabcc',1,'Text']]],
  ['settextcolor_33',['SetTextColor',['../class_text.html#a192df3aa0b28e33617c7e538fa830ebb',1,'Text']]],
  ['shape_34',['Shape',['../class_shape.html',1,'Shape'],['../class_shape.html#a2750fe1e686ff854a4eef36ffdd9dd29',1,'Shape::Shape(QPen pen, QBrush brush, Coord coord)']]],
  ['shapecoord_35',['shapeCoord',['../class_shape.html#af8ca043a0badd58ed55d06ac4ff1392a',1,'Shape']]]
];
