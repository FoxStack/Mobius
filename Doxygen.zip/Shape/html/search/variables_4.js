var searchData=
[
  ['y_96',['y',['../struct_coord.html#a214166cca70cef7dda9201689c3e81ab',1,'Coord']]]
];
