var searchData=
[
  ['text_36',['Text',['../class_text.html',1,'Text'],['../class_text.html#a4dc801a0e4306036fb7ac97a5aa6ea10',1,'Text::Text()']]]
];
