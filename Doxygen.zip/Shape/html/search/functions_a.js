var searchData=
[
  ['text_82',['Text',['../class_text.html#a4dc801a0e4306036fb7ac97a5aa6ea10',1,'Text']]]
];
