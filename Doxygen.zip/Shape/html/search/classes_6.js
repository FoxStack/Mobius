var searchData=
[
  ['text_52',['Text',['../class_text.html',1,'']]]
];
