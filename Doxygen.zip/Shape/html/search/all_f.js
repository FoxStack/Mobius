var searchData=
[
  ['y_38',['y',['../struct_coord.html#a214166cca70cef7dda9201689c3e81ab',1,'Coord']]]
];
