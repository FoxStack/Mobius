var searchData=
[
  ['x_37',['x',['../struct_coord.html#a696eaa744360fc791d0e3b331c549dbe',1,'Coord']]]
];
