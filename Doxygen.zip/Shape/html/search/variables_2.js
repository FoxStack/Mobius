var searchData=
[
  ['shapecoord_94',['shapeCoord',['../class_shape.html#af8ca043a0badd58ed55d06ac4ff1392a',1,'Shape']]]
];
