var searchData=
[
  ['coord_2',['Coord',['../struct_coord.html',1,'']]]
];
