var searchData=
[
  ['coord_45',['Coord',['../struct_coord.html',1,'']]]
];
