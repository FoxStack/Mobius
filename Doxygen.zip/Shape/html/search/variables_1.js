var searchData=
[
  ['qbrush_90',['qBrush',['../class_shape.html#a644ffe2539068095e6a6ddb6635dd6b2',1,'Shape']]],
  ['qpaintdevice_91',['qPaintDevice',['../class_shape.html#a7eff35cae19efe8a9c36b2902b984d04',1,'Shape']]],
  ['qpainter_92',['qPainter',['../class_shape.html#af0234579d5d1df44bb97b20437170ef5',1,'Shape']]],
  ['qpen_93',['qPen',['../class_shape.html#a26c6a30a98522abb67ea0a16de9d887c',1,'Shape']]]
];
