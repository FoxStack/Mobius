var searchData=
[
  ['getid_57',['GetId',['../class_shape.html#a619cb49e2f5acdbecf216f262fa2a85f',1,'Shape']]]
];
