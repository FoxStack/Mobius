var searchData=
[
  ['rbegin_81',['rbegin',['../class_vector.html#a7e113a51e4317bc1231669340ccdee7f',1,'Vector']]],
  ['rend_82',['rend',['../class_vector.html#ad91aef9471385734d28c8dd72a6b9a38',1,'Vector']]],
  ['reserve_83',['reserve',['../class_vector.html#a4b0f3d561c3be42d558180814b8fc50d',1,'Vector']]],
  ['resize_84',['resize',['../class_vector.html#a985cab40b66023e05fbe40e2c9b281e7',1,'Vector']]],
  ['reverse_85',['reverse',['../classreverse.html#a716e163c2a6ae511cdc8c84e842485be',1,'reverse::reverse(T *ptr=nullptr)'],['../classreverse.html#ad9ef4fdcf7b32ad73f2b3b8944e7ba66',1,'reverse::reverse(const iterator&lt; T &gt; &amp;rawit)'],['../classreverse.html#a2609a87b677349e6f8ec221a93f91e54',1,'reverse::reverse(const reverse&lt; T &gt; &amp;rrawit)=default']]]
];
