var searchData=
[
  ['data_9',['data',['../class_vector.html#aa1a539921b7d016cef8335a15ca7650d',1,'Vector::data()'],['../class_vector.html#a1a3af41741c26a6f7529977384bcc93d',1,'Vector::data() const']]]
];
