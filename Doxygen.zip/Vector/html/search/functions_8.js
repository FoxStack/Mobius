var searchData=
[
  ['max_5fsize_65',['max_size',['../class_vector.html#ab1689e556079b9d655034ca8b8df115a',1,'Vector']]]
];
