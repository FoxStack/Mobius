var searchData=
[
  ['pop_5fback_32',['pop_back',['../class_vector.html#adcba035109febbe55cba2a25f8483ba6',1,'Vector']]],
  ['push_5fback_33',['push_back',['../class_vector.html#a8a99f38a10024ca8b4a9cc262d969f27',1,'Vector']]]
];
