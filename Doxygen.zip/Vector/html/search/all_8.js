var searchData=
[
  ['m_5fptr_17',['m_ptr',['../classiterator.html#a9fc8aca3d44fba02141d4276c37a1c9e',1,'iterator']]],
  ['max_5fsize_18',['max_size',['../class_vector.html#ab1689e556079b9d655034ca8b8df115a',1,'Vector']]]
];
