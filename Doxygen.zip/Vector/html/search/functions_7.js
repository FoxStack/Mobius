var searchData=
[
  ['iterator_64',['iterator',['../classiterator.html#a0d9f7d7582c28328f583fb70c0bce8bc',1,'iterator::iterator(T *ptr=nullptr)'],['../classiterator.html#a90694b3220febbb0b17c7c79689bffd0',1,'iterator::iterator(const iterator&lt; T &gt; &amp;rawit)=default']]]
];
