var searchData=
[
  ['getdefaultbrush_4',['getDefaultBrush',['../class_render_area.html#a798ec9dcb377ffec1320d12fb71c2c12',1,'RenderArea']]],
  ['getdefaultpen_5',['getDefaultPen',['../class_render_area.html#a1f10c83b074de15a6b5e4fe3e2723294',1,'RenderArea']]]
];
