var searchData=
[
  ['addshape_21',['AddShape',['../class_render_area.html#a04eb8bafa16e2b3ed45ef8ffb1ace4f5',1,'RenderArea']]],
  ['addtext_22',['AddText',['../class_render_area.html#a32787729cb0988eb99ed29f895236846',1,'RenderArea']]]
];
