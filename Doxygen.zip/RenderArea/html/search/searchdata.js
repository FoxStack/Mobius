var indexSectionsWithContent =
{
  0: "aeglmprs",
  1: "r",
  2: "agmprs",
  3: "e",
  4: "elpr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "enums",
  4: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Enumerations",
  4: "Enumerator"
};

