var searchData=
[
  ['setbrush_14',['setBrush',['../class_render_area.html#a89dbd44a79ba820ae8d651f30abc56b1',1,'RenderArea']]],
  ['setcolor_15',['setColor',['../class_render_area.html#afa3078e1ca60c28f3f3b3e6b921ff7c6',1,'RenderArea']]],
  ['setcurrentshapeid_16',['setCurrentShapeId',['../class_render_area.html#ad90f00719f58c2f8d3833d108e915c5f',1,'RenderArea']]],
  ['setpen_17',['setPen',['../class_render_area.html#a209db7987984687b05ee02e6784ad782',1,'RenderArea']]],
  ['settext_18',['setText',['../class_render_area.html#a5d6c0d8a1e15802093f957162965b733',1,'RenderArea']]],
  ['sizehint_19',['sizeHint',['../class_render_area.html#ac0b3e7195c5ba16eaa6590168db0f0cf',1,'RenderArea']]]
];
