/*
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import <Foundation/Foundation.h>

@class GULRuntimeClassSnapshot;
@class GULRuntimeDiff;

NS_ASSUME_NONNULL_BEGIN

/** This class captures various aspects the current state of the Objective-C runtime. */
@interface GULRuntimeSnapshot : NSObject

/** Initializes an instance of this class. The designated initializer.
 *
 *  @param classes The set of classes to track. If nil or empty, all ObjC classes are tracked.
 *  @return An instance of this class.
 */
- (instancetype)initWithClasses:(nullable NSSet<Class> *)classes NS_DESIGNATED_INITIALIZER;

/** Captures the state of the class set. */
- (void)capture;

/** Computes the diff between this snapshot and another snapshot.
 *
 *  @param otherSnapshot The other snapshot, assumed to be more recent than self.
 *  @return A diff object populated with the diff.
 */
- (GULRuntimeDiff *)diff:(GULRuntimeSnapshot *)otherSnapshot;

@end

NS_ASSUME_NONNULL_END
